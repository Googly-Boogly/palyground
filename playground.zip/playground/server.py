from flask import render_template,redirect,request,session,flash
from flask_app.templates import app
import re



@app.route("/play")
def register():

    return render_template("index.html")

@app.route("/play/<int:id_1>")
def registeggr(id_1):
    i = 0
    arr = []
    while i != id_1:
        arr.append(i)
        i += 1
    return render_template("multi.html", total=arr)

@app.route("/play/<int:id_1>/<strin>")
def registegggfr(id_1, strin):
    i = 0
    arr = []
    strin2 = (f'background-color:{strin}; color:{strin}; border: 3px solid black;')
    print(strin2)
    while i != id_1:
        arr.append(i)
        i += 1
    return render_template("multi2.html", total=arr, strin=strin2)


if __name__ == "__main__":
    app.run(debug=True)